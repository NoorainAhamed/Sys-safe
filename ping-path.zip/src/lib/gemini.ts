import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.GEMINI_API_KEY;

export const ai = new GoogleGenAI({ apiKey: API_KEY || "" });

export interface SecurityThreat {
  id: string;
  description: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface SecurityAuditResult {
  threats: SecurityThreat[];
  recommendations: string[];
  securityScore: number;
  summary: string;
}

export async function performSecurityAudit(context: string): Promise<SecurityAuditResult> {
  if (!API_KEY) {
    return {
      threats: [{ id: '1', description: "API Key missing. Cannot perform deep security audit.", severity: 'CRITICAL' }],
      recommendations: ["Configure your GEMINI_API_KEY in the secrets panel."],
      securityScore: 0,
      summary: "Security audit unavailable without AI configuration."
    };
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-flash-latest",
      contents: `You are a cybersecurity expert. Perform a simulated security audit based on this browser/device context: ${context}. 
      Return a JSON object with: 
      - threats: list of objects with { "id": "uuid", "description": "threat description", "severity": "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" }.
      - recommendations: list of actionable security steps.
      - securityScore: number from 0-100 indicating safety.
      - summary: brief summary sentence.
      Keep it realistic for a web-based scan. Focus on potential vulnerabilities like outdated browser, suspicious user agent, etc.`,
      config: {
        responseMimeType: "application/json",
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error: any) {
    console.error("Audit failed:", error);
    
    // Check for 403 Permission Denied
    const errorString = JSON.stringify(error);
    if (errorString.includes("PERMISSION_DENIED") || errorString.includes("403")) {
      return {
        threats: [{ 
          id: 'auth-error', 
          description: "Gemini API Access Denied. Please ensure your GEMINI_API_KEY is correctly configured in Settings > Secrets.", 
          severity: 'CRITICAL' 
        }],
        recommendations: ["Check AI Studio Secrets panel.", "Ensure the selected API key has access to gemini-3-flash-preview."],
        securityScore: 0,
        summary: "Security audit failed due to API permission issues."
      };
    }

    return {
      threats: [{ id: 'error', description: "External audit service unreachable or failed.", severity: 'MEDIUM' }],
      recommendations: ["Check network connection.", "Retry scan later."],
      securityScore: 50,
      summary: "Partial local scan completed. External analysis failed."
    };
  }
}
